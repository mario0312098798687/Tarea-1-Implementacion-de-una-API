"""
Sistema de Acreditación de Estudiantes
Backend API — Flask + SQLite
"""

import re
import sqlite3

from flask import Flask, jsonify, request
from flask_cors import CORS
from stdnum.do import cedula as cedula_do

app = Flask(__name__)
CORS(app)

DATABASE = "acreditaciones.db"
ROL_ESTUDIANTE = "Estudiante"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS acreditados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            cedula TEXT NOT NULL UNIQUE,
            rol TEXT NOT NULL DEFAULT 'Estudiante',
            zona_acceso TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


def limpiar_cedula(valor):
    return re.sub(r"\D", "", str(valor or ""))


def formatear_cedula(valor):
    numero = limpiar_cedula(valor)
    if len(numero) != 11:
        return numero
    return cedula_do.format(numero)


def validar_cedula(valor):
    numero = limpiar_cedula(valor)
    if not cedula_do.is_valid(numero):
        return False, "La cédula no es válida. Verifique el número y el dígito verificador."
    return True, formatear_cedula(numero)


@app.route("/cedula/<path:valor>", methods=["GET"])
def validar_cedula_endpoint(valor):
    es_valida, resultado = validar_cedula(valor)
    if not es_valida:
        return jsonify({"valida": False, "error": resultado}), 400
    return jsonify({"valida": True, "cedula": resultado})


@app.route("/acreditados", methods=["POST"])
def crear_acreditado():
    data = request.get_json(silent=True) or {}

    nombre = (data.get("nombre") or "").strip()
    cedula_raw = (data.get("cedula") or "").strip()
    zona_acceso = (data.get("zona_acceso") or "").strip()

    if not all([nombre, cedula_raw, zona_acceso]):
        return jsonify({"error": "Todos los campos son obligatorios."}), 400

    es_valida, resultado = validar_cedula(cedula_raw)
    if not es_valida:
        return jsonify({"error": resultado}), 400

    cedula = resultado

    conn = get_db()
    try:
        cursor = conn.execute(
            """
            INSERT INTO acreditados (nombre, cedula, rol, zona_acceso)
            VALUES (?, ?, ?, ?)
            """,
            (nombre, cedula, ROL_ESTUDIANTE, zona_acceso),
        )
        conn.commit()
        nuevo = conn.execute(
            "SELECT * FROM acreditados WHERE id = ?", (cursor.lastrowid,)
        ).fetchone()
        return jsonify(dict(nuevo)), 201
    except sqlite3.IntegrityError:
        return jsonify({
            "error": "Este estudiante ya está acreditado en el sistema.",
            "cedula": cedula,
        }), 400
    finally:
        conn.close()


@app.route("/acreditados", methods=["GET"])
def listar_acreditados():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM acreditados ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])


@app.route("/estadisticas", methods=["GET"])
def estadisticas():
    conn = get_db()
    rows = conn.execute(
        """
        SELECT zona_acceso, COUNT(*) AS total
        FROM acreditados
        GROUP BY zona_acceso
        ORDER BY total DESC
        """
    ).fetchall()
    conn.close()
    return jsonify([
        {"zona_acceso": row["zona_acceso"], "total": row["total"]}
        for row in rows
    ])


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "servicio": "Acreditación de Estudiantes"})


if __name__ == "__main__":
    init_db()
    print("=" * 50)
    print("  Acreditación de Estudiantes — API activa")
    print("  http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, host="0.0.0.0", port=5000)
